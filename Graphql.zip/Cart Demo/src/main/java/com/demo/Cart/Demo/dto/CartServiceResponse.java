package com.demo.Cart.Demo.dto;

public class CartServiceResponse {
    private String defaultDeliveryDate;

   /* private LocalDate defaultDeliveryDate;
    private LocalDate requestedDeliveryDate;
    private boolean currentCart;
    private CartDeliveryMode deliveryMode;
    private List<PaymentInfo> paymentInfos;
    private List<CartEntries> entries;*/

    public String getDefaultDeliveryDate() {
        return defaultDeliveryDate;
    }

    public void setDefaultDeliveryDate(String defaultDeliveryDate) {
        this.defaultDeliveryDate = defaultDeliveryDate;
    }

    public CartServiceResponse(String defaultDeliveryDate) {
        this.defaultDeliveryDate = defaultDeliveryDate;
    }

   /*  public CartServiceResponse(int id, int totalItems, int totalPrice, int totalTax, int totalPriceWithTax, LocalDate defaultDeliveryDate, LocalDate requestedDeliveryDate, boolean currentCart, CartDeliveryMode deliveryMode, List<PaymentInfo> paymentInfos, List<CartEntries> entries) {
        this.id = id;
        this.totalItems = totalItems;
        this.totalPrice = totalPrice;
        this.totalTax = totalTax;
        this.totalPriceWithTax = totalPriceWithTax;
        this.defaultDeliveryDate = defaultDeliveryDate;
        this.requestedDeliveryDate = requestedDeliveryDate;
        this.currentCart = currentCart;
        this.deliveryMode = deliveryMode;
        this.paymentInfos = paymentInfos;
        this.entries = entries;
    }*/

   /* public float getId() {
        return id;
    }

    public void setId(float id) {
        this.id = id;
    }
*/
    /*  public int getTotalItems() {
        return totalItems;
    }

    public void setTotalItems(int totalItems) {
        this.totalItems = totalItems;
    }

    public int getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(int totalPrice) {
        this.totalPrice = totalPrice;
    }

    public int getTotalTax() {
        return totalTax;
    }

    public void setTotalTax(int totalTax) {
        this.totalTax = totalTax;
    }

    public int getTotalPriceWithTax() {
        return totalPriceWithTax;
    }

    public void setTotalPriceWithTax(int totalPriceWithTax) {
        this.totalPriceWithTax = totalPriceWithTax;
    }*/

 /*   public LocalDate getDefaultDeliveryDate() {
        return defaultDeliveryDate;
    }

    public void setDefaultDeliveryDate(LocalDate defaultDeliveryDate) {
        this.defaultDeliveryDate = defaultDeliveryDate;
    }

    public LocalDate getRequestedDeliveryDate() {
        return requestedDeliveryDate;
    }

    public void setRequestedDeliveryDate(LocalDate requestedDeliveryDate) {
        this.requestedDeliveryDate = requestedDeliveryDate;
    }

    public boolean isCurrentCart() {
        return currentCart;
    }

    public void setCurrentCart(boolean currentCart) {
        this.currentCart = currentCart;
    }

    public CartDeliveryMode getDeliveryMode() {
        return deliveryMode;
    }

    public void setDeliveryMode(CartDeliveryMode deliveryMode) {
        this.deliveryMode = deliveryMode;
    }

    public List<PaymentInfo> getPaymentInfos() {
        return paymentInfos;
    }

    public void setPaymentInfos(List<PaymentInfo> paymentInfos) {
        this.paymentInfos = paymentInfos;
    }

    public List<CartEntries> getEntries() {
        return entries;
    }

    public void setEntries(List<CartEntries> entries) {
        this.entries = entries;
    }*/
}
