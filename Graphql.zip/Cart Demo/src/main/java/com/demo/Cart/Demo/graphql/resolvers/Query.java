package com.demo.Cart.Demo.graphql.resolvers;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.demo.Cart.Demo.dto.CartSummaryInfo;
import com.demo.Cart.Demo.service.CartService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class Query implements GraphQLQueryResolver {

    private final Logger logger = LoggerFactory.getLogger(getClass());
    private CartService cartService;

    public Query(CartService cartService) {
        this.cartService = cartService;
    }

    public CartSummaryInfo getCartDetail(String username) {
        return cartService.getCartItems(username);
    }
}
