package com.demo.Cart.Demo.dto;

import java.util.List;

public class CartSummaryInfo {
    private float totalPrice;
    private float totalTax;
    private float totalPriceWithTax;
    private List<CartItems> items;

    public CartSummaryInfo() {
    }

    public CartSummaryInfo(float totalPrice, float totalTax, float totalPriceWithTax, List<CartItems> items) {
        this.totalPrice = totalPrice;
        this.totalTax = totalTax;
        this.totalPriceWithTax = totalPriceWithTax;
        this.items = items;
    }

    public float getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(float totalPrice) {
        this.totalPrice = totalPrice;
    }

    public float getTotalTax() {
        return totalTax;
    }

    public void setTotalTax(float totalTax) {
        this.totalTax = totalTax;
    }

    public float getTotalPriceWithTax() {
        return totalPriceWithTax;
    }

    public void setTotalPriceWithTax(float totalPriceWithTax) {
        this.totalPriceWithTax = totalPriceWithTax;
    }

    public List<CartItems> getItems() {
        return items;
    }

    public void setItems(List<CartItems> items) {
        this.items = items;
    }
}
