package com.demo.Cart.Demo.service;

import com.demo.Cart.Demo.dto.CartSummaryInfo;

public interface CartService {
    CartSummaryInfo getCartItems(String username);
}
