package com.demo.Cart.Demo.dto;

public class    Medias {
    private int id;
    private String mediaId;
    private String name;
    private String url;
    private String fileFormat;
    private Boolean primaryImage;

    public Medias() {
    }

    public Medias(int id, String mediaId, String name, String url, String fileFormat, Boolean primaryImage) {
        this.id = id;
        this.mediaId = mediaId;
        this.name = name;
        this.url = url;
        this.fileFormat = fileFormat;
        this.primaryImage = primaryImage;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMediaId() {
        return mediaId;
    }

    public void setMediaId(String mediaId) {
        this.mediaId = mediaId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getFileFormat() {
        return fileFormat;
    }

    public void setFileFormat(String fileFormat) {
        this.fileFormat = fileFormat;
    }

    public Boolean getPrimaryImage() {
        return primaryImage;
    }

    public void setPrimaryImage(Boolean primaryImage) {
        this.primaryImage = primaryImage;
    }
}
