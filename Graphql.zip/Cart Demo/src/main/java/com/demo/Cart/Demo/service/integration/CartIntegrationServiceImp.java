package com.demo.Cart.Demo.service.integration;

import com.demo.Cart.Demo.dto.CartResponse;
import com.demo.Cart.Demo.dto.CartResponseData;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.File;
import java.io.IOException;

@Service
public class CartIntegrationServiceImp implements CartIntegrationService {

    private final Logger logger = LoggerFactory.getLogger(getClass());

    public CartIntegrationServiceImp() {
    }


    @Override
    public CartResponse getCartItems(String username) {
        ObjectMapper objectMapper = new ObjectMapper();
        CartResponse cartResponse = null;
        try {
            cartResponse = objectMapper.readValue(new File("src/main/resources/currentcartNew.json"), CartResponse.class);
            logger.info(cartResponse.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return cartResponse;
    }

    @Override
    public CartResponse getCartDetails(String username) {
        ResponseEntity<CartResponse> response;
        try {
            final RestTemplate restTemplate = new RestTemplate();

            ((org.springframework.http.client.SimpleClientHttpRequestFactory)
                    restTemplate.getRequestFactory()).setReadTimeout(3000000);

            ((org.springframework.http.client.SimpleClientHttpRequestFactory)
                    restTemplate.getRequestFactory()).setConnectTimeout(3000000);

            response = restTemplate.exchange(
                    "http://inchcmlp02707:8090/api/users/kbk2@techm.com/cart/currentCart",
                    HttpMethod.GET,
                    HttpEntity.EMPTY,
                    CartResponse.class
            );
        } catch (RestClientException e) {
            logger.error(e.getMessage());
            return null;
        }
        if (HttpStatus.OK == response.getStatusCode()) {
            return response.getBody();
        }
        return null;
    }
}