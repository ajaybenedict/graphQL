package com.demo.Cart.Demo.dto;

public class CartEntries {
    private int id;
    private float quantity;
    private Product product;

    public CartEntries() {
    }

    public CartEntries(int id, float quantity, Product product) {
        this.id = id;
        this.quantity = quantity;
        this.product = product;
    }

    public float getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public float getQuantity() {
        return quantity;
    }

    public void setQuantity(float quantity) {
        this.quantity = quantity;
    }


    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

}
