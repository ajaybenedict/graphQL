package com.demo.Cart.Demo.dto;

import java.util.List;

public class Product {
    private int id;
    private String productId;
    private String name;
    private String url;
    private String description;
    private String summary;
    private String manufacturer;
    private String approvalStatus;
    private String validFrom;
    private String validTo;
    private int minOrderQuantity;
    private int maxOrderQuantity;
    private String saleUnit;
    private int isActive;
    private int isPurchasable;
    private int isAvailableForPickup;
    private float averageRating;
    private int numberOfReviews;
    private int isVariant;
    private String productType;
    private List<Medias> medias;
    private List<Prices> prices;

    public Product() {
    }

    public Product(int id, String productId, String name, String url, String description, String summary, String manufacturer, String approvalStatus,
                   String validFrom, String validTo, int minOrderQuantity,
                   int maxOrderQuantity, String saleUnit, int isActive,
                   int isPurchasable, int isAvailableForPickup, int averageRating,
                   int numberOfReviews, int isVariant, String productType, List<Medias> medias, List<Prices> prices) {
        this.id = id;
        this.productId = productId;
        this.name = name;
        this.url = url;
        this.description = description;
        this.summary = summary;
        this.manufacturer = manufacturer;
        this.approvalStatus = approvalStatus;
        this.validFrom = validFrom;
        this.validTo = validTo;
        this.minOrderQuantity = minOrderQuantity;
        this.maxOrderQuantity = maxOrderQuantity;
        this.saleUnit = saleUnit;
        this.isActive = isActive;
        this.isPurchasable = isPurchasable;
        this.isAvailableForPickup = isAvailableForPickup;
        this.averageRating = averageRating;
        this.numberOfReviews = numberOfReviews;
        this.isVariant = isVariant;
        this.productType = productType;
        this.medias = medias;
        this.prices = prices;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getApprovalStatus() {
        return approvalStatus;
    }

    public void setApprovalStatus(String approvalStatus) {
        this.approvalStatus = approvalStatus;
    }

    public float getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getValidFrom() {
        return validFrom;
    }

    public void setValidFrom(String validFrom) {
        this.validFrom = validFrom;
    }

    public String getValidTo() {
        return validTo;
    }

    public void setValidTo(String validTo) {
        this.validTo = validTo;
    }

    public int getMinOrderQuantity() {
        return minOrderQuantity;
    }

    public void setMinOrderQuantity(int minOrderQuantity) {
        this.minOrderQuantity = minOrderQuantity;
    }

    public int getMaxOrderQuantity() {
        return maxOrderQuantity;
    }

    public void setMaxOrderQuantity(int maxOrderQuantity) {
        this.maxOrderQuantity = maxOrderQuantity;
    }

    public String getSaleUnit() {
        return saleUnit;
    }

    public void setSaleUnit(String saleUnit) {
        this.saleUnit = saleUnit;
    }

    public int getIsActive() {
        return isActive;
    }

    public void setIsActive(int isActive) {
        this.isActive = isActive;
    }

    public int getIsPurchasable() {
        return isPurchasable;
    }

    public void setIsPurchasable(int isPurchasable) {
        this.isPurchasable = isPurchasable;
    }

    public int getIsAvailableForPickup() {
        return isAvailableForPickup;
    }

    public void setIsAvailableForPickup(int isAvailableForPickup) {
        this.isAvailableForPickup = isAvailableForPickup;
    }

    public float getAverageRating() {
        return averageRating;
    }

    public void setAverageRating(int averageRating) {
        this.averageRating = averageRating;
    }

    public int getNumberOfReviews() {
        return numberOfReviews;
    }

    public void setNumberOfReviews(int numberOfReviews) {
        this.numberOfReviews = numberOfReviews;
    }

    public int getIsVariant() {
        return isVariant;
    }

    public void setIsVariant(int isVariant) {
        this.isVariant = isVariant;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public List<Medias> getMedias() {
        return medias;
    }

    public void setMedias(List<Medias> medias) {
        this.medias = medias;
    }

    public List<Prices> getPrices() {
        return prices;
    }

    public void setPrices(List<Prices> prices) {
        this.prices = prices;
    }
}
