package com.demo.Cart.Demo.dto;

public class CreditCard {
    private float id;
    private String cardNumber;
    private String cardType;
    private String lastName;
    private String firstName;

    public CreditCard() {
    }

    public CreditCard(float id, String cardNumber, String cardType, String lastName, String firstName) {
        this.id = id;
        this.cardNumber = cardNumber;
        this.cardType = cardType;
        this.lastName = lastName;
        this.firstName = firstName;
    }

    public float getId() {
        return id;
    }

    public void setId(float id) {
        this.id = id;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
}
