package com.demo.Cart.Demo.dto;

public class Prices {
    private int id;
    private String priceId;
    private String currency;
    private int priceValue;
    private String unit;
    private int number_of_units;

    public Prices() {
    }

    public Prices(int id, String priceId, String currency, int priceValue, String unit, int number_of_units) {
        this.id = id;
        this.priceId = priceId;
        this.currency = currency;
        this.priceValue = priceValue;
        this.unit = unit;
        this.number_of_units = number_of_units;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPriceId() {
        return priceId;
    }

    public void setPriceId(String priceId) {
        this.priceId = priceId;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public int getPriceValue() {
        return priceValue;
    }

    public void setPriceValue(int priceValue) {
        this.priceValue = priceValue;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public int getNumber_of_units() {
        return number_of_units;
    }

    public void setNumber_of_units(int number_of_units) {
        this.number_of_units = number_of_units;
    }
}
