package com.demo.Cart.Demo.dto;

import java.util.ArrayList;

public class CartResponseData {
    private int id;
    private float totalItems;
    private int totalPrice;
    private int totalTax;
    private int totalPriceWithTax;
    private boolean currentCart;
    ArrayList < CartEntries > entries = new ArrayList < CartEntries > ();


    // Getter Methods

    public int getId() {
        return id;
    }

    public float getTotalItems() {
        return totalItems;
    }

    public float getTotalPrice() {
        return totalPrice;
    }

    public float getTotalTax() {
        return totalTax;
    }

    public float getTotalPriceWithTax() {
        return totalPriceWithTax;
    }

    public boolean isCurrentCart() {
        return currentCart;
    }

// Setter Methods

    public void setId(int id) {
        this.id = id;
    }

    public void setTotalItems(float totalItems) {
        this.totalItems = totalItems;
    }

    public void setTotalPrice(int totalPrice) {
        this.totalPrice = totalPrice;
    }

    public void setTotalTax(int totalTax) {
        this.totalTax = totalTax;
    }

    public void setTotalPriceWithTax(int totalPriceWithTax) {
        this.totalPriceWithTax = totalPriceWithTax;
    }

    public void setCurrentCart(boolean currentCart) {
        this.currentCart = currentCart;
    }

    public ArrayList<CartEntries> getEntries() {
        return entries;
    }

    public void setEntries(ArrayList<CartEntries> entries) {
        this.entries = entries;
    }



    @Override
    public String toString() {
        return "CartResponseData{" +
                "id=" + id +
                ", totalItems=" + totalItems +
                ", totalPrice=" + totalPrice +
                ", totalTax=" + totalTax +
                ", totalPriceWithTax=" + totalPriceWithTax +
                ", currentCart=" + currentCart +
                ", entries=" + entries +
                '}';
    }
}
