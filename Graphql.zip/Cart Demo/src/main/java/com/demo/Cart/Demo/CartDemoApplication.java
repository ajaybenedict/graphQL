package com.demo.Cart.Demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.env.Environment;

import java.net.InetAddress;
import java.net.UnknownHostException;

@SpringBootApplication
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class})
public class CartDemoApplication {
    private static final Logger log = LoggerFactory.getLogger(CartDemoApplication.class);

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(CartDemoApplication.class);
        ApplicationContext context = app.run(args);
        Environment env = context.getEnvironment();
        String port = env.getProperty("server.port", "8080");
        String schema =
                env.getProperty("server.ssl.enabled", Boolean.class, Boolean.FALSE) ? "https" : "http";
        log.info("Local: \t\t{}://127.0.0.1:{}", schema, port);
        try {
            log.info("External: \t{}://{}:{}", schema, InetAddress.getLocalHost().getHostAddress(), port);
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
    }
}
