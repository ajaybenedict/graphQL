package com.demo.Cart.Demo.dto;

import java.time.LocalDate;

public class PaymentInfo {
    private int id;
    private String paymentType;
    private CreditCard creditCard;
    private float amount;
    private String status;
    private String transactionDate;

    public PaymentInfo() {
    }

    public PaymentInfo(int id, String paymentType, CreditCard creditCard, float amount, String status, String transactionDate) {
        this.id = id;
        this.paymentType = paymentType;
        this.creditCard = creditCard;
        this.amount = amount;
        this.status = status;
        this.transactionDate = transactionDate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public CreditCard getCreditCard() {
        return creditCard;
    }

    public void setCreditCard(CreditCard creditCard) {
        this.creditCard = creditCard;
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public void setTransactionDate(String transactionDate) {
        this.transactionDate = transactionDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
