package com.demo.Cart.Demo.service.integration;

import com.demo.Cart.Demo.dto.CartResponse;

public interface CartIntegrationService {

    CartResponse getCartItems(String username);

    CartResponse getCartDetails(String username);
}
