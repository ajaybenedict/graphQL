package com.demo.Cart.Demo.service;

import com.demo.Cart.Demo.dto.*;
import com.demo.Cart.Demo.service.integration.CartIntegrationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CartServiceImp implements CartService {

    private final Logger logger = LoggerFactory.getLogger(getClass());
    private CartIntegrationService cartIntegrationService;

    public CartServiceImp(CartIntegrationService cartIntegrationService) {
        this.cartIntegrationService = cartIntegrationService;
    }

    @Override
    public CartSummaryInfo getCartItems(String username) {
        //CartResponse cartServiceResponses = cartIntegrationService.getCartDetails(username);
        CartResponse cartServiceResponses = cartIntegrationService.getCartItems(username);
        CartSummaryInfo cartSummaryInfos = convertCartSummaryInfo(cartServiceResponses.getData());
        return cartSummaryInfos;
    }

    private CartSummaryInfo convertCartSummaryInfo(CartResponseData cartServiceResponses) {
        return Optional.of(cartServiceResponses)
                .map(cartServiceResponse -> new CartSummaryInfo(cartServiceResponse.getTotalPrice(),
                        cartServiceResponse.getTotalTax(), cartServiceResponse.getTotalPriceWithTax(),
                        convertCartEntries(cartServiceResponse.getEntries()))).orElse(null);
    }

    private List<CartItems> convertCartEntries(List<CartEntries> entries) {
        if (entries != null) {
            return entries.stream()
                    .map(cartEntries -> new CartItems(cartEntries.getProduct().getProductId(),
                            cartEntries.getProduct().getName(), cartEntries.getProduct().getMedias().get(0).getUrl(),
                            cartEntries.getQuantity()))
                    .collect(Collectors.toList());
        }
        return null;
    }
}