package com.demo.Cart.Demo.dto;

public class CartResponse {
private CartResponseData data;

    public CartResponse() {
    }

    public CartResponse(CartResponseData data) {
        this.data = data;
    }

    public CartResponseData getData() {
        return data;
    }

    public void setData(CartResponseData data) {
        this.data = data;
    }
}
